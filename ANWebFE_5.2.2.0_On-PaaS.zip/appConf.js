var http = require('http');

http.createServer(function (req, res) {
    
	try {
        const config = {
			CLIENT_ID: process.env.CLIENT_ID,
			AZURE_STORAGE_RESOURCE: process.env.AZURE_STORAGE_RESOURCE,
			BASE_URL: process.env.BASE_URL,
			API_BASE_URL: process.env.API_BASE_URL
		};
		
		const headers = {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
			'Pragma': 'no-cache',
            'Expires': '0'
        };
        
        res.writeHead(200, headers);
		res.end(JSON.stringify(config));
		
    } catch (err) {
        res.writeHead(500);
        res.end(err.toString());
    }
	
}).listen(process.env.PORT);