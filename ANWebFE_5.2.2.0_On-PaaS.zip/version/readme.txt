----------------------------------------------------------------------------------------------------------------------------
5.2.2.0 (2022-12-06)
----------------------------------------------------------------------------------------------------------------------------

- add "Security" section in appSettings
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.2.1.0 (2022-11-07)
----------------------------------------------------------------------------------------------------------------------------

- remove "IExplorerWarning" section in appSettings
- update "News" section in appSettings
- update images
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.25.3 (2022-11-25)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.25.2 (2022-11-10)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.25.1 (2022-11-04)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.25.0 (2022-10-14)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.24.0 (2022-08-11)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.23.2 (2022-07-26)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.23.1 (2022-07-20)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.23.0 (2022-07-07)
----------------------------------------------------------------------------------------------------------------------------

- add "News" section in appSettings
- remove "Preview" section in appSettings
- update translation files
- update menuDesktop file
- update images

----------------------------------------------------------------------------------------------------------------------------
5.1.22.0 (2022-06-01)
----------------------------------------------------------------------------------------------------------------------------

- update "Preview" section in appSettings
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.21.0 (2022-05-04)
----------------------------------------------------------------------------------------------------------------------------

- update "Preview" section in appSettings

----------------------------------------------------------------------------------------------------------------------------
5.1.20.0 (2022-03-14)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.19.0 (2022-02-04)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.18.0 (2021-12-30)
----------------------------------------------------------------------------------------------------------------------------

- add HtmlViewer section in appSettings
- add translation files
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.17.0 (2021-12-03)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.16.1 (2021-11-12)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.16.0 (2021-11-02)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.15.2 (2021-10-15)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.15.1 (2021-10-12)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.15.0 (2021-10-07)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.14.1 (2021-09-27)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.14.0 (2021-09-02)
----------------------------------------------------------------------------------------------------------------------------

- added app settings custom file
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.13.0 (2021-07-30)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.12.1 (2021-07-14)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.12.0 (2021-06-28)
----------------------------------------------------------------------------------------------------------------------------

- update json menu files
- remove mobile json file
- update "Preview" section in appSettings
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.11.2 (2021-06-01)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.11.1 (2021-05-27)
----------------------------------------------------------------------------------------------------------------------------

- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.11.0 (2021-05-04)
----------------------------------------------------------------------------------------------------------------------------

- add "Spinner" section in appSettings
- update "Preview" section in appSettings
- add "ENGAGE_favicon.ico" in images files
- add "ENGAGE_header.png" in images files
- add "ENGAGE_logo.png" in images files
- add "ENGAGE_payoff.png" in images files
- remove "CONTINUITY_favicon.ico" from images files
- remove "CONTINUITY_header.png" from images files
- remove "CONTINUITY_logo.png" from images files
- remove "CONTINUITY_payoff.png" from images files
- remove "ShowActivitiesWaiting" from appSettings
- update translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.10.8 (2021-04-22)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.10.7 (2021-04-08)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.10.6 (2021-03-29)
----------------------------------------------------------------------------------------------------------------------------

- update "Preview" section in appSettings
- add "TASK_TREE_FILTER_SEARCH" in translation files
- add "TASK_TREE_FILTER_EXPAND_TREE" in translation files
- add "TASK_TREE_FILTER_COLLAPSE_TREE" in translation files
- remove "WORKFLOW_TASKTREE_FILTER" from translation files
- remove "WORKFLOW_TASKTREE_EXPAND_TREE" from translation files
- remove "WORKFLOW_TASKTREE_COLLAPSE_TREE" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.10.5 (2021-03-01)
----------------------------------------------------------------------------------------------------------------------------

- add "Preview" section in appSettings

----------------------------------------------------------------------------------------------------------------------------
5.1.10.4 (2021-02-11)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.10.3 (2021-02-08)
----------------------------------------------------------------------------------------------------------------------------

- add "MicrosoftTeams" section in appSettings
- remove "MICROSOFT_TEAMS_TAB_NAME" from translation files
- remove "MICROSOFT_TEAMS_TAB_NAME_PLACEHOLDER" from translation files
- remove "MICROSOFT_TEAMS_TAB_URL" from translation files
- remove "MICROSOFT_TEAMS_TAB_URL_PLACEHOLDER" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.10.2 (2021-01-27)
----------------------------------------------------------------------------------------------------------------------------

- remove "CPM_VIEWER_TABLE_ENABLE_CHAT" in translation files
- update "MENU_CHAT" in translation files
- update "CHAT_PAGE_TITLE" in translation files
- update "CHAT_PAGE_WORKFLOW_TITLE" in translation files
- update "CPM_DETAIL_CHAT" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.10.1 (2021-01-14)
----------------------------------------------------------------------------------------------------------------------------

- added MESA_version to img folder

----------------------------------------------------------------------------------------------------------------------------
5.1.10.0 (2020-12-31)
----------------------------------------------------------------------------------------------------------------------------

- remove systemLayout from layout folders
- add "USER_APPLICATION_VIEWER_TITLE" in translation files
- add "USER_APPLICATION_VIEWER_NEW" in translation files
- add "USER_APPLICATION_VIEWER_EDIT" in translation files
- add "USER_APPLICATION_VIEWER_ACCESS_NOTIFICATION" in translation files
- add "USER_APPLICATION_VIEWER_RESET_PASSWORD" in translation files
- add "USER_APPLICATION_VIEWER_UNLOCK_USER" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_ACCESS_BLOCKED" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_CONTAINER" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_DISPLAY_NAME" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_EMAIL" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_USER_NAME" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_STATUS" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_STATUS_DISABLED" in translation files
- add "USER_APPLICATION_VIEWER_TABLE_STATUS_ENABLED" in translation files 
- add "USER_APPLICATION_VIEWER_DIALOG_TITLE" in translation files 
- add "USER_APPLICATION_VIEWER_DIALOG_NOTIFICATION_TEXT" in translation files
- add "USER_APPLICATION_VIEWER_DIALOG_RESET_PASSWORD_TEXT" in translation files
- add "USER_APPLICATION_VIEWER_DIALOG_UNLOCK_USER_TEXT" in translation files
- add "USER_APPLICATION_DETAIL_ADD_TITLE" in translation files
- add "USER_APPLICATION_DETAIL_EDIT_TITLE" in translation files
- add "USER_APPLICATION_DETAIL_USER_DISPLAY_NAME" in translation files
- add "USER_APPLICATION_DETAIL_EMAIL" in translation files
- add "USER_APPLICATION_DETAIL_EMAIL_ERROR" in translation files
- add "USER_APPLICATION_DETAIL_USERNAME" in translation files
- add "USER_APPLICATION_DETAIL_HOMEPAGE" in tranlsation files
- add "USER_APPLICATION_DETAIL_CONTAINER" in translation files
- add "USER_APPLICATION_DETAIL_USER_ENABLED" in translation files
- add "USER_APPLICATION_DETAIL_USER_ENABLED_OTP" in translation files
- add "USER_APPLICATION_DETAIL_USER_SEND_MAIL" in translation files
- add "USER_APPLICATION_LOGIN_DUPLICATE_EMAIL" in translation files
- add "USER_APPLICATION_DETAIL_USER_LANGUAGE" in translation files
- add "WORKFLOW_TASKTREE_COLLAPSE_TREE" in translation files
- add "WORKFLOW_TASKTREE_EXPAND_TREE" in translation files
- add "WORKFLOW_TASKTREE_COLLAPSE_PANEL" in translation files
- add "WORKFLOW_TASKTREE_EXPAND_PANEL" in translation files
- add "USER_APPLICATION_DETAIL_USER_CONTAINER" in translation files
- update "USER_VIEWER_TABLE_STATUS_DISABLED" in translation files


----------------------------------------------------------------------------------------------------------------------------
5.1.9.3 (2020-12-23)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.9.2 (2020-12-22)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.9.1 (2020-12-11)
----------------------------------------------------------------------------------------------------------------------------

- add "ERROR_FILE_EMPTY" in translation files
- add "ERROR_SCHEMA_FORM_VALIDATION_NOT_CONFIGURED" in translation files

----------------------------------------------------------------------------------------------------------------------------

5.1.9.0 (2020-11-30)
----------------------------------------------------------------------------------------------------------------------------

- add "CPM_DETAIL_EXPANDED_LEVELS" in translation files
- add "ADMIN_TASK_PROPERTIES_LEVELS_EXPANDED" in translation files
- add "ERROR_INACTIVE_USER" in translation files
- update "ADMIN_TASK_PROPERTIES_LOGIC_CHILDREN" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.8.3 (2020-11-20)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.8.2 (2020-11-19)
----------------------------------------------------------------------------------------------------------------------------

- add "MOBILE_TASK_ACTION_DETAILS" in translation files
- update "ADMIN_TASK_PROPERTIES_SHOW_DETAILS" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.8.1 (2020-11-10)
----------------------------------------------------------------------------------------------------------------------------

- update "applications" section in menu mobile
- add "MOBILE_TASK_ACTION_CHAT" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.8.0 (2020-11-02)
----------------------------------------------------------------------------------------------------------------------------

- remove "AZURE_STORAGE_RESOURCE" from appConf files
- update img folder
- update "Theme" section in appSettings
- add "ADMIN_TASK_PROPERTIES_SHOW_DETAILS" in translation files
- add "CPM_DETAIL_SAVE_CONFIRM_DESCRIPTION" In translation files
- add "CPM_DETAIL_SAVE_CONFIRM_TITLE" In translation files
- add "MOBILE_TASK_ACTION_ADD_TASK_FAVORITES" in translation files
- add "MOBILE_TASK_ACTION_REMOVE_TASK_FAVORITES" in translation files
- update "CPM_DETAIL_SHOW_DETAIL" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.7.3 (2020-10-28)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.7.2 (2020-10-20)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.7.1 (2020-10-14)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.7.0 (2020-10-01)
----------------------------------------------------------------------------------------------------------------------------

- add "TASK_LOG_TABLE_ACTION" in translation files
- add "TASK_LOG_TABLE_STATUS" in translation files
- add "TASK_LOG_TABLE_USER_NAME" in translation files
- add "TASK_LOG_TABLE_DATE" in translation files
- add "CPM_DETAIL_TASK_LOG" in translation files
- add "TASK_LOG_SURVEY_SP_TITLE" in translation files
- add "TASK_LOG_TITLE" in translation files
- add "TASK_GRID_EXPORT_BUTTON" in translation files
- add "PRINT_ALREADY_REQUESTED" in translation files
- remove "CPM_DETAIL_ALWAYS_OPEN" from translation files
- remove "TASK_LOG_AXELENCE_TITLE" from translation files
- remove "TASK_LOG_AXE_TABLE_USER" from translation files
- remove "TASK_LOG_AXE_TABLE_DOWNLOAD_DATE" from translation files
- remove "TASK_LOG_AXE_TABLE_OPEN_DATE" from translation files
- remove "TASK_LOG_AXE_TABLE_PARAMETERS" from translation files
- remove "TASK_LOG_AXE_TABLE_STATUS" from translation files
- remove "TASK_LOG_STORED_PROCEDURE_TITLE" from translation files
- remove "TOOLBAR_TASK_LOG" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.6.5 (2020-10-01)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.6.4 (2020-09-28)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.6.3 (2020-09-23)
----------------------------------------------------------------------------------------------------------------------------

- add "ERROR_DIMENSION_WITH_MULTIPLE_KEYS" in translation files
- add "DIM_ENTITY_FIELD_STATUS_UPDATED_DATA_TYPE" in translation files
- add "DIM_ENTITY_FIELD_STATUS_UPDATED_KEY" in translation files
- remove "DIM_ENTITY_FIELD_STATUS_UPDATED" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.6.2 (2020-09-16)
----------------------------------------------------------------------------------------------------------------------------

- add "DIM_ENTITY_DIMENSION_DESCRIPTION_LABEL" in translation files
- add "DIM_ENTITY_DIMENSION_DESCRIPTION_LABEL_NOTE" in translation files
- add "DIM_ENTITY_PROCEDURE_LABEL" in translation files
- updated "DIM_ENTITY_TYPE" in translation files
- remove "DIM_ENTITY_DIMENSION_DESCRIPTION" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.6.1 (2020-09-01)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.6.0 (2020-08-14)
----------------------------------------------------------------------------------------------------------------------------

- remove "Achievements" section in themes file
- add "DIM_PROJECT_PAGE_TITLE" in translation files
- add "ERROR_INVALID_CONNECTION_CREDENTIALS" in translation files
- add "ERROR_INVALID_CONNECTION_NAME" in translation files
- add "DIM_PROJECT_PAGE_PROJECT_CONNECTION" in translation files
- add "DIM_PROJECT_PAGE_PROJECT_CONTAINER" in translation files
- add "DIM_PROJECT_PAGE_PROJECT_EDIT" in translation files
- add "DIM_PROJECT_PAGE_PROJECT_DESCRIPTION" in translation files
- add "DIM_PROJECT_PAGE_PROJECT_NAME" in translation files
- add "DIM_PROJECT_DETAIL_ADD_PROJECT_CONNECTION" in translation files
- add "DIM_PROJECT_DETAIL_ADD_PROJECT_DESCRIPTION" in translation files
- add "DIM_PROJECT_DETAIL_ADD_PROJECT_NAME" in translation files
- add "DIM_PROJECT_DETAIL_ADD_PROJECT_TITLE" in translation files
- add "DIM_PROJECT_DETAIL_EDIT_PROJECT_TITLE" in translation files
- add "DIM_PROJECT_PAGE_MANAGE_ENTITIES" in translation files
- add "DIM_PROJECT_PAGE_PROJECT_ADD" in translation files
- add "DIM_CONNECTION_DETAIL_ADD_CONNECTION_DATABASE" in translation files
- add "DIM_CONNECTION_DETAIL_ADD_CONNECTION_NAME" in translation files
- add "DIM_CONNECTION_DETAIL_ADD_CONNECTION_PASSWORD" in translation files
- add "DIM_CONNECTION_DETAIL_ADD_CONNECTION_SERVER" in translation files
- add "DIM_CONNECTION_DETAIL_ADD_CONNECTION_TITLE" in translation files
- add "DIM_CONNECTION_DETAIL_ADD_CONNECTION_USERNAME" in translation files
- add "DIM_CONNECTION_DETAIL_EDIT_CONNECTION_TITLE" in translation files
- add "DIM_CONNECTION_PAGE_CONNECTION_ADD" in translation files
- add "DIM_CONNECTION_PAGE_CONNECTION_DATABASE" in translation files
- add "DIM_CONNECTION_PAGE_CONNECTION_EDIT" in translation files
- add "DIM_CONNECTION_PAGE_CONNECTION_NAME" in translation files
- add "DIM_CONNECTION_PAGE_CONNECTION_SERVER" in translation files
- add "DIM_CONNECTION_PAGE_TITLE" in translation files
- add "DIM_MAIN_TOOLBAR_MANAGE_CONNECTIONS" in translation files
- add "DIM_MAIN_TOOLBAR_MANAGE_PROJECTS" in translation files
- add "DIM_ENTITY_WRITE_TABLE" in translation files
- add "DIM_ENTITY_READ_TABLE" in translation files
- add "DIM_ENTITY_DESCRIPTION" in translation files
- add "DIM_ENTITY_NAME" in translation files
- add "DIM_ENTITY_TITLE_NEW" in translation files
- add "DIM_DIALOG_CLEAR_DATA_TITLE" in translation files
- add "DIM_DIALOG_CLEAR_DATA_CONTENT" in translation files
- add "DIM_DIALOG_DELETE_TITLE" in translation files
- add "DIM_DIALOG_DELETE_CONTENT" in translation files
- add "ERROR_INVALID_PUBLISH_REPORT" in translation files
- add "DIM_ENTITY_FIELD_DATA_TYPE" in translation files
- add "DIM_ENTITY_FIELD_NAME" in translation files
- add "DIM_ENTITY_FIELD_DIM_DATA_MODEL" in translation files
- add "DIM_ENTITY_FIELD_SMART_NAME" in translation files
- add "DIM_ENTITY_DIMENSION_DESCRIPTION" in translation files
- add "DIM_ENTITY_TRACE_DATE" in translation files
- add "DIM_ENTITY_TRACE_USER" in translation files
- add "DIM_ENTITY_POSTWRITING_PROCEDURE" in translation files
- add "DIM_ENTITY_PREWRITING_PROCEDURE" in translation files
- add "DIM_ENTITY_POSTREADING_PROCEDURE" in translation files
- add "DIM_ENTITY_PREREADING_PROCEDURE" in translation files
- add "DIM_ENTITY_TYPE_STANDARD" in translation files
- add "DIM_ENTITY_TYPE_RECTIFICATION" in translation files
- add "DIM_ENTITY_TYPE_STANDARD_UDPATE" in translation files
- add "DIM_ENTITY_TYPE" in translation files
- add "DIM_ENTITY_FIELD_ACCESS_TYPE_READ" in translation files
- add "DIM_ENTITY_FIELD_ACCESS_TYPE_READ_AND_WRITE" in translation files
- add "DIM_ENTITY_FIELD_ACCESS_TYPE_WRITE" in translation files
- add "DIM_ENTITY_FIELD_ACCESS_TYPE_READ_WRITE" in translation files
- add "DIM_ENTITY_FIELD_ACCESS_TYPE" in translation files
- add "DIM_ENTITY_DIMENSION_UNIQUE_DESCRIPTION" in translation files
- add "ERROR_INVALID_ENTITY_NAME" in translation files
- add "DIM_ENTITY_TREE_NAVBAR_SEARCH" in translation files
- add "DIM_ENTITIES_PAGE_TITLE" in translation files
- add "ERROR_PASSWORD_RECOVER" in translation files
- add "ERROR_PASSWORD_RECOVER_ALREADY_SENT" in translation files
- add "ERROR_PASSWORD_RECOVER_EXPIRED_CODE" in translation files
- add "ERROR_PASSWORD_RECOVER_INVALID_CODE" in translation files
- add "LOGIN_FORGOT_PASSWORD_SENT in translation files
- add "ERROR_INVALID_ENTITY_USED" in translation files
- add "DIM_ENTITY_FIELD_STATUS_ADDED" in translation files
- add "DIM_ENTITY_FIELD_STATUS_UPDATED" in translation files
- add "DIM_ENTITY_FIELD_STATUS_DELETED" in translation files
- add "LOGIN_FORGOT_PASSWORD_DISCLAIMER_HEAD" in translation files
- add "LOGIN_FORGOT_PASSWORD_DISCLAIMER_BODY" in translation files
- add "LOGIN_FORGOT_PASSWORD_BACK" in translation files
- add "LOGIN_FORGOT_PASSWORD_SEND" in translation files
- add "DIM_ENTITY_DELETED_WARNING" in translation files
- update "VIDEO_DELETE_TITLE" in translation files
- update "CPM_VIEWER_TITLE" in translation files
- remove "MANAGE_OBJECT_UPLOAD_DOCUMENT_FORM" from translation files
- remove "MANAGE_OBJECT_UPLOAD_DOCUMENT_SCHEMA" from translation files
- remove "MANAGE_OBJECT_UPLOAD_DOCUMENT_SCHEMA_NOT_VALID" from translation files
- remove "MANAGE_OBJECT_UPLOAD_DOCUMENT_FORM_NOT_VALID" from translation files
- remove "MANAGE_OBJECT_UPLOAD_DOCUMENT_SHOW_ON_BOTTOM" from translation files
- remove "UPLOAD_DOCUMENT_SAVE_DRAFT" from translation files
- remove "UPLOAD_DOCUMENT_CONFIRM" from translation files
- remove "UPLOAD_DOCUMENT_LAST_MODIFIED" from translation files
- remove "UPLOAD_DOCUMENT_FILE_ADD" from translation files
- remove "UPLOAD_DOCUMENT_FILE_DOWNLOAD" from translation files
- remove "UPLOAD_DOCUMENT_NO_FILE_ERROR" from translation files
- remove "UPLOAD_DOCUMENT_DELETE_TITLE" from translation files
- remove "UPLOAD_DOCUMENT_DELETE_DESCRIPTION" from translation files
- remove "ADMIN_ROLES_PROPERTIES_CONTAINER_DESCRIPTION" from translation files
- remove "WORKFLOW_MENU_ACHIEVEMENTS_PAGE_TITLE" from translation files,
- remove "ACHIEVEMENTS_NO_ITEMS" from translation files,
- remove "ACHIEVEMENTS_MOBILE_DESCRIPTION" from translation files
- remove "ACHIEVEMENTS_TITLE" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.5.3 (2020-07-28)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.5.2 (2020-07-06)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.5.1 (2020-06-19)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.5.0 (2020-06-09)
----------------------------------------------------------------------------------------------------------------------------

- add "MANAGE_OBJECT_ASSESMENT_RANDOM_QUESTION_NUMBER" in translation files
- add "MANAGE_OBJECT_TASK_GRID_TYPE" in translation files
- add "MICROSOFT_TEAMS_TAB_NAME" in translation files
- add "MICROSOFT_TEAMS_TAB_NAME_PLACEHOLDER" in translation files
- add "MICROSOFT_TEAMS_TAB_URL" in translation files
- add "MICROSOFT_TEAMS_TAB_URL_PLACEHOLDER" in translation files
- add "MANAGE_OBJECT_SCORM_FILE_ADD" in translation files
- add "MANAGE_OBJECT_SCORM_NO_FILE_ERROR" in translation files
- update "TASK_LOG_NO_DATA" in translation files
- remove "TASK_LOG_TITLE" from translation files
- remove "TASK_LOG_POST_EXECUTION_TITLE" from translation files
- remove "TASK_LOG_TABLE_STATUS" from translation files
- remove "TASK_GRID_PAGE_TABLE_STATUS" from translation files
- remove "TASK_GRID_PAGE_TABLE_DESCRIPTION" from translation files
- remove "TASK_GRID_PAGE_TABLE_FATHER_DESCRIPTION" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.4.3 (2020-05-28)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.4.2 (2020-05-05)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.4.1 (2020-04-23)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.4.0 (2020-04-09)
----------------------------------------------------------------------------------------------------------------------------

- add "ADMIN_ROLES_PROPERTIES_CONTAINER_DESCRIPTION" in translation files
- add "ADMIN_TASK_PROPERTIES_NEWS" in translation files
- add "MANAGE_NEWS_DESCRIPTION" in translation files
- add "MANAGE_NEWS_FILE_ADD_IMAGE" in translation files
- add "MANAGE_NEWS_NO_FILE_IMAGE_ERROR" in translation files
- add "MANAGE_NEWS_CATEGORY" in translation files
- add "MANAGE_NEWS_TITLE" in translation files
- add "MANAGE_NEWS_ABSTRACT" in translation files
- add "MANAGE_NEWS_PUBLISH_DATE" in translation files
- add "MANAGE_NEWS_DUE_DATE" in translation files
- add "MANAGE_NEWS_MAIN_NEWS" in translation files
- add "SMART_DOCUMENT_AUDIT_LAST_MODIFIED" in translation files
- add "SHOW_MORE_NEWS" in translation files
- add "ROLE_DETAIL_CONTAINER_DESCRIPTION" in translation files
- update "ROLE_DETAIL_ADD_TITLE" in translation files
- update "ROLE_DETAIL_EDIT_TITLE" in translation files
- remove "MANAGE_OBJECT_NEWS_FILE_ADD_IMAGE" from translation files
- remove "MANAGE_OBJECT_NEWS_NO_FILE_IMAGE_ERROR" from translation files
- remove "MANAGE_OBJECT_NEWS_CATEGORY" from translation files
- remove "MANAGE_OBJECT_NEWS_TITLE" from translation files
- remove "MANAGE_OBJECT_NEWS_ABSTRACT" from translation files
- remove "MANAGE_OBJECT_NEWS_PUBLISH_DATE" from translation files
- remove "MANAGE_OBJECT_NEWS_DUE_DATE" from translation files
- remove "SESSION_EXPIRED" from translation files
- add "PrimaryColorDisabled" in theme files
- add "PrimaryForegroundColorDisabled" in theme files
- update favorites "MaterialIcon" in menu

----------------------------------------------------------------------------------------------------------------------------
5.1.3.1 (2020-03-03)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.3.0 (2020-02-27)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.2.1 (2020-02-26)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.2.0 (2020-02-19)
----------------------------------------------------------------------------------------------------------------------------

- add "CPM_DETAIL_EMAIL" in translation files
- add "CPM_DETAIL_EMAIL_NOT_VALID" in translation files
- add "MANAGE_OBJECT_GRID_DATASET_TEMPLATE" in translation files
- add "GRID_ACTION_INSERT_SAVE" in translation files
- add "GRID_ACTION_INSERT_BACK" in translation files
- add "GRID_ACTION_VIEW_BACK" in translation files
- add "GRID_ACTION_UPDATE_SAVE" in translation files
- add "GRID_ACTION_UPDATE_BACK" in translation files
- add "GRID_ROW_DELETE_TITLE" in translation files
- add "GRID_ROW_DELETE_DESCRIPTION" in translation files
- update "ROLE_VIEWER_MANAGE" in translation files
- update "USER_PROFILE_PREVIOUS_PAGE" in translation files
- update "ROLE_VIEWER_TITLE" in translation files
- remove "MOBILE_WORKFLOW_STRUCTURE" from translation files
- remove "MOBILE_WORKFLOW_ACTIVITY" from translation files
- remove "MOBILE_WORKFLOW_CONTENT" from translation files
- remove "MOBILE_WORKFLOW_TODO" from translation files
- remove "MOBILE_WORKFLOW_WAITING" from translation files
- remove "MOBILE_WORKFLOW_REPORT" from translation files
- remove "MOBILE_WORKFLOW_MEDIA" from translation files
- remove "MOBILE_WORKFLOW_DOCS" from translation files
- remove "MANAGE_OBJECT_SURVEY_SHOW_ON_BOTTOM" from translation files
- remove "MANAGE_OBJECT_SURVEY_ONLY_CONFIRM" from translation files
- remove "SURVEY_FILE_ADD" from translation files
- remove "SURVEY_SAVE_DRAFT" from translation files
- remove "SURVEY_CONFIRM" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.1.3 (2020-02-12)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.1.2 (2020-02-03)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.1.1 (2020-01-27)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.1.1.0 (2020-01-23)
----------------------------------------------------------------------------------------------------------------------------

- add "ADMIN_TASK_TREE_CLONE_TASK" in translation files
- add "ADMIN_TASK_TREE_REFRESH_TASK" in translation files
- add "MANAGE_OBJECT_SMART_DOCUMENT_ADD_WORD" in translation files
- add "MANAGE_OBJECT_SMART_DOCUMENT_ADD_WORD_ERROR" in translation files
- add "MANAGE_OBJECT_SMART_DOCUMENT_JSON_CONFIGURATION" in translation files
- add "MANAGE_OBJECT_SMART_DOCUMENT_JSON_CONFIGURATION_NOT_VALID" in translation files
- add "MANAGE_OBJECT_SP_PARAMETER" in translation files
- add "MANAGE_OBJECT_TASK_GRID_CONFIGURATION" in translation files
- add "MANAGE_OBJECT_TASK_GRID_CONFIGURATION_NOT_VALID" in translation files
- add "MANAGE_OBJECT_TASK_GRID_SHOW_FATHER" in translation files
- add "MANAGE_SP_POST_ACTION_ADD" in translation files
- add "MANAGE_SP_POST_ACTION_EDIT" in translation files
- add "MANAGE_SP_POST_ACTION_VIEW" in translation files
- add "MANAGE_SP_POST_ACTION_DESCRIPTION" in translation files
- add "MANAGE_SP_POST_ACTION_DETAILS" in translation files
- add "SMART_DOCUMENT_DELETE_TITLE" in translation files
- add "SMART_DOCUMENT_DELETE_DESCRIPTION" in translation files
- add "SMART_DOCUMENT_CONFIGURATION" in translation files
- add "USER_PROFILE_PREVIOUS_PAGE" in translation files
- remove "ADMIN_TASK_TREE_CLONE" in translation files
- remove "TASK_TAB_ACTIVITY" from translation filesles
- remove "TASK_TAB_CHAT" from translation files
- remove "TASK_TAB_DETAILS" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.1.0.0 (2020-01-03)
----------------------------------------------------------------------------------------------------------------------------

- nothing to update

----------------------------------------------------------------------------------------------------------------------------
5.0.16.0 (2019-12-19)
----------------------------------------------------------------------------------------------------------------------------

- add translations/schemaForm files
- add "ERROR_LOGIN_TYPE_NOT_VALID" in translation files
- add "LIBRARY_LIST_EMPTY_LIST" in translation files
- add "ADMIN_TASK_PROPERTIES_TASK_GRID_BUTTON" in translation files
- add "ADMIN_TASK_TREE_SHOW_INFO" in translation files
- add "MANAGE_OBJECT_SKIP_DRILL_DOWN" in translation files
- add "TASK_GRID_PAGE_TABLE_DESCRIPTION" in translation files
- add "TASK_GRID_PAGE_TABLE_STATUS" in translation files
- add "TASK_GRID_PAGE_TABLE_FATHER_DESCRIPTION" in translation files
- add "TASK_GRID_PAGE_TABLE_LINK" in translation files
- add "TASK_GRID_DELETE_TITLE" in translation files
- add "TASK_GRID_DELETE_DESCRIPTION" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_VIRTUAL_ASSISTANT_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_CPM_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_CHILDREN_LOGIC_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_LOGIC_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_NOTIFYTYPE_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_ON_POST_ACTION_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_SMARTOBJECT_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_SMARTOBJECT_TYPE_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_STORED_PROC_OBJECT_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_TASK_ID" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_ENTITY" in translation files
- add "WORKFLOW_ADMIN_SHOW_INFO_ENTITY_ID" in translation files
- removed "UPLOAD_FILE_REQUIRED" in translation files
- removed "MULTILINE_TEXT_REQUIRED" in translation files
- update "DATEPICKER_DATE_REQUIRED" in translation files
- update "FILE_VIEWER_FILE_INFO" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.15.0 (2019-12-05)
----------------------------------------------------------------------------------------------------------------------------

- add "IExplorerWarning" section in appSettings
- add "OTP_MESSAGE_HEADER" in translation files
- add "OTP_MESSAGE" in translation files
- add "OTP_LABEL" in translation files
- add "OTP_RESEND_CODE" in translation files
- add "OTP_RESEND_CODE_COMPLETED" in translation files
- add "OTP_DONE" in translation files
- add "OTP_CANCEL" in translation files
- add "LOGIN_AD_DOMAIN" in translation files
- add "ERROR_FORCED_LOGIN_TITLE" in translation files
- add "ERROR_FORCED_LOGIN_LINK" in translation files
- add "ROLES_ADMIN_ROLE_SEARCH" in translation files
- add "TASK_AUTH_NO_MATCHES" in translation files
- add "TASK_AUTH_ONLY_AUTHORIZED in translation files
- removed "LOGIN_OTP_MESSAGE_HEADER" from translation files
- removed "LOGIN_OTP_MESSAGE" from translation files
- removed "LOGIN_OTP" from translation files
- removed "LOGIN_OTP_RESEND_CODE" from translation files
- removed "LOGIN_OTP_RESEND_CODE_COMPLETED" from translation files
- removed "LOGIN_OTP_DONE" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.14.1 (2019-11-22)
----------------------------------------------------------------------------------------------------------------------------

- changed "Enabled" to true in mobile.json for "applications" entry
- insert "ERROR_PASSWORD_ALREADY_PRESENT_IN_HISTORY": in translation files
- insert "ERROR_PASSWORD_TIMESTAMP_NOT_VALID": in translation files
- insert "ERROR_PASSWORD_SHOW_RULES" in translation files
- insert "ERROR_PASSWORD_SHORT" in translation files
- update "ERROR_PASSWORD_MISMATCH" in translation files
- remove "ERROR_PASSWORD_TIME_NOT_VALID" from translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_TIMESTAMP_NOT_VALID" from translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.14.0 (2019-11-14)
----------------------------------------------------------------------------------------------------------------------------

- insert "MANAGE_OBJECT_STYLECSS" in translation files
- insert "MANAGE_OBJECT_ASSESMENT_MAX_NUMBER_OF_ATTEMPS" in translation files
- insert "ASSESMENT_STATUS_NOT_ACHIEVED" in translation files
- insert "ASSESMENT_STATUS_NOT_ACHIEVED_MESSAGE" in translation files
- insert "MANAGE_OBJECT_ASSESMENT_HIGHLIGHT_WRONG_ANSWERS" in translation files
- insert "ASSESMENT_STATUS_ACHIEVED_MESSAGE" in translation files
- insert "ASSESMENT_STATUS_ACHIEVED" in translation files
- insert "ASSESMENT_STATUS_MAX_ATTEMPTS_REACHED" in translation files
- insert "ASSESMENT_STATUS_NUMBER_OF_ATTEMPS" in translation files
- insert "ASSESMENT_STATUS_MAX_NUMBER_OF_ATTEMPS" in translation files
- insert "UPLOAD_FILE_REQUIRED" in translation files
- insert "CHAT_VIRTUAL_ASSISTANT_RATE"  in translation files
- update "ASSESMENT_STATUS_NEW_QUALIFICATION" in translation files
- update "ERROR_PASSWORD_MISMATCH" in translation files
- remove "ASSESMENT_SAVE_DRAFT" from translation files
- remove "ASSESMENT_CONFIRM" from translation files
- remove "SEARCH_AT" from translation files
- remove "SEARCH_HASH" from translation files
- remove "SEARCH_MEDIA" from translation files
- remove "SEARCH_PLACEHOLDER" from translation files
- remove "SEARCH_PLACEHOLDER_AT" from translation files
- remove "SEARCH_PLACEHOLDER_HASH" from translation files
- remove "SEARCH_PLACEHOLDER_MEDIA" from translation files
- remove "SEARCH_RELATED" from translation files
- remove "SEARCH_TITLE_BAR" from translation files
- remove "SEARCH_LAST_SEARCH" from translation files
- remove "searchAt.png" from images files
- remove "searchHash.png" from images files
- remove "searchMedia.png" from images files
- remove "MANAGE_OBJECT_SURVEY_STYLECSS" in translation files
- remove "MANAGE_OBJECT_ASSESMENT_NUMBER_OF_QUESTIONS" in translation files
- remove "ASSESMENT_STATUS_EXCEEDED_MESSAGE" in translation files
- remove "ASSESMENT_STATUS_EXCEEDED" in translation files
- remove "ASSESMENT_STATUS_FAILED" in translation files
- remove "ASSESMENT_STATUS_FAILED_MESSAGE" in translation files
- add "ShowActivitiesWaiting" in appSettings.json
- remove "TreeConfig" section from appSettings.json
- remove "TimerOffset" section from appSettings.json

----------------------------------------------------------------------------------------------------------------------------
5.0.13.0 (2019-10-16)
----------------------------------------------------------------------------------------------------------------------------

- insert "UPLOAD_FILE_ADD" in translation files
- insert "MANAGE_OBJECT_NEWS_PUBLISH_DATE" in translation files
- insert "MANAGE_OBJECT_NEWS_DUE_DATE" in translation files
- insert "PROCESS_DETAIL_ORDER_MAX_NUMBER_ORDER" in translation files
- insert "MANAGE_OBJECT_SURVEY_STYLECSS" in translation files
- remove "MANAGE_OBJECT_SURVEY_CONFIGURATION_NOT_VALID" in translation files
- remove "MANAGE_OBJECT_SURVEY_CONFIGURATION_VALID" in translation files
- insert "PROCESS_VIEWER_TABLE_ORDER" in translation files
- insert "PROCESS_DETAIL_ORDER" in translation files
- insert "HTML_EDITOR_REQUIRED" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.12.0 (2019-10-01)
----------------------------------------------------------------------------------------------------------------------------

- remove "File" section in appSettings
- changed "BadgeEnabled" to true in desktop.json and mobile.json for "activity" entry
- insert "LOGIN_OTP" in translation files
- insert "LOGIN_OTP_MESSAGE_HEADER" in translation files
- insert "LOGIN_OTP_MESSAGE" in translation files
- insert "LOGIN_OTP_RESEND_CODE" in translation files
- insert "LOGIN_OTP_DONE" in translation files
- insert "ERROR_OTP_INVALID" in translation files
- insert "LOGIN_OTP_RESEND_CODE_COMPLETED" in translation files
- insert "ERROR_PASSWORD_TIME_NOT_VALID" in translation files
- insert "USER_LOGIN_DETAIL_OPT_ENABLED" in translation files
- insert "ERROR_PASSWORD_NOT_SATISFY_REQUIREMENTS" in translation files
- insert "CHAT_VIRTUAL_ASSISTANT_REQUEST_CLARIFICATION" in translation files
- insert "USER_LOGIN_VIEWER_TABLE_LOCKED_EXPIRATION_TIME" in translation files
- insert "USER_LOGIN_UNLOCK" in translation files
- insert "ERROR_LOCKED_USER" in translation files
- insert "SESSION_EXPIRED" in translation files
- insert "CHANGE_PWD_PASSWORD_ERROR_A_DAY_FOR_CHANGE_PASSWORD" in translation files
- insert "ERROR_FILE_EXTENSION" in translation files
- insert "LOGIN_SUCCESS_MESSAGE" in translation files
- insert "ERROR_BAD_REQUEST" in translation files
- insert "ERROR_EMAIL_ERROR" in translation files
- insert "ERROR_RESOURCE_NOT_FOUND" in translation files
- insert "ERROR_SERVER_ERROR" in translation files
- insert "ERROR_FORBIDDEN_ACCESS" in translation files
- update "ERROR_PASSWORD_MISMATCH" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_INCLUDE_UPPER" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_INCLUDE_LOWER" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_INCLUDE_NUMBER" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_INCLUDE_NOT_LETTER_OR_DIGIT" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_SHORT" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_TIMESTAMP_NOT_VALID" in translation files
- remove "CHANGE_PWD_PASSWORD_ERROR_SAME_PASSWORD" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.11.0 (2019-09-06)
----------------------------------------------------------------------------------------------------------------------------

- update "SURVEY_AUDIT_LAST_MODIFIED" in translation files
- update "ASSESMENT_STATUS_LAST_MODIFIED" in translation files
- insert "NAVIGATOR_SERVICE_CHECK_START_TRANSITION_WOULD_YOU_LIKE_TO_CONTINUE" in translation files
- insert "NAVIGATOR_SERVICE_CHECK_START_TRANSITION_ALL_CHANGES_WILL_BE_LOST" in translation files
- insert "NAVIGATOR_SERVICE_CHECK_START_TRANSITION_CONTINUE_YES" in translation files
- insert "NAVIGATOR_SERVICE_CHECK_START_TRANSITION_CONTINUE_NO" in translation files
- insert "MANAGE_OBJECT_SURVEY_PANEL_CONFIGURATION" in translation files
- insert "MANAGE_OBJECT_SURVEY_PANEL_CONFIGURATION_NOT_VALID" in translation files
- insert "CHAT_STATUS_AT" in translation files
- insert "INTERACTION_MODEL_DATAMODEL_FIELD_WRITE_MODES_STANDARD" in translation files
- insert "INTERACTION_MODEL_DATAMODEL_FIELD_TYPES_RECTIFICATION" in translation files
- insert "INTERACTION_MODEL_DATAMODEL_FIELD_TYPES_VERSIONING" in translation files
- insert "INTERACTION_MODEL_CONNECTION_EDIT_PASSWORD_NOT_CHANGED" in translation files
- insert "INTERACTION_MODEL_DIALOG_CONFIRM_DELETE_MESSAGE_TEXT" in translation files
- insert "INTERACTION_MODEL_PROJECT_NAME_REQUIRED_TO_CONTINUE" in translation files
- insert "INTERACTION_MODEL_PROJECT_MISSING_CORRECT_VALUES_IN_TABLES" in translation files
- insert "MANAGE_OBJECT_SURVEY_CONFIGURATION_NOT_VALID" in translation files
- insert "MANAGE_OBJECT_SURVEY_CONFIGURATION_VALID" in translation files
- remove "Actions" section in theme files
- remove "Component News" section in theme files
- remove "INTERACTION_MODEL_PROJECT_NAME_REQUIRED_TO_CONTINUE" in translation files
- remove "INTERACTION_MODEL_CONNECTION_EDIT_PASSWORD_NOT_CHANGED" in translation files
- updated "INTERACTION_MODEL_DIALOG_CONFIRM_DELETE_MESSAGE_TEXT" in translation files
- updated "INTERACTION_MODEL_PROJECT_CONFIRM" in translation files
- update "MULTI_SELECTION_LIST_NO_ITEMS" in translation files
- update "INTERACTION_MODEL_PROJECT_DELETE_OK" in translation files
- update "INTERACTION_MODEL_DIALOG_CONFIRM_OK" in translation files
- update "MANAGE_OBJECT_SURVEY_PANEL_CONFIGURATION" in translation files
- update json menu files

----------------------------------------------------------------------------------------------------------------------------
5.0.10.1 (2019-07-31)
----------------------------------------------------------------------------------------------------------------------------

- remove "SURVEY_PRINT" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.10.0 (2019-07-26)
----------------------------------------------------------------------------------------------------------------------------

- sync all INTERACTION_MODEL_xxx in translation files
- add "CHAT_VIRTUAL_ASSISTANT_USER_QUESTION" in translation files
- add "CHAT_VIRTUAL_ASSISTANT_SELECTED_QUESTION" in translation files
- add "CHAT_VIRTUAL_ASSISTANT_RESPONSE" in translation files
- add "CHAT_VIRTUAL_ASSISTANT_NO_RESPONSE" in translation files
- add "CHAT_VIRTUAL_ASSISTANT_SELECTED_SCOPE" in translation files
- add "CHAT_VIRTUAL_ASSISTANT_QUESTION_TEXT" in translation files
- add "CHAT_VIRTUAL_ASSISTANT_SCOPE" in translation files	
- add MainToolbarDesktop section in theme files

----------------------------------------------------------------------------------------------------------------------------
5.0.9.1 (2019-07-01)
----------------------------------------------------------------------------------------------------------------------------

- add "VIEW_DOCUMENT_FULL_SCREEN" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.9.0 (2019-07-01)
----------------------------------------------------------------------------------------------------------------------------

- add "Plugins" section in appSettings file
- add "plugins" folder as a resource
- add "PLUGIN_DELETE_TITLE" in translation files
- add "PLUGIN_DELETE_DESCRIPTION" in translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_ADVERSE_MEDIA" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_ENTITY" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_ID" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_PUBLISHED_TIME" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_RED_FLAG" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_RCTIS" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_SENTIMENT" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_SNIPPET" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_SOURCE_URL" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_TITLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TABLE_TOPIC" from translation files
- remove "ADVERSE_MEDIA_VIEWER_TITLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_ORIGINAL_LANGUAGE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_DUE_DILIGENCE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_RED_FLAG_ENABLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_RED_FLAG_DISABLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_ADVERSE_MEDIA_ENABLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_ADVERSE_MEDIA_DISABLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_STATIC_FILE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_VIEW_ARTICLE" from translation files
- remove "ADVERSE_MEDIA_VIEWER_REFRESH" from translation files
- remove "TOOLBAR_TASK_STATUS" from translation files
- remove "TOOLBAR_TASK_DETAILS" from translation files
- update "CHAT_PANEL_ADD_COMMENT" in translation files
- update menu desktop.json application item set enable to false
	
----------------------------------------------------------------------------------------------------------------------------
5.0.8.0 (2019-06-26)
----------------------------------------------------------------------------------------------------------------------------

- add "MULTILINE_TEXT_REQUIRED" in translation files
- add "MULTI_SELECTION_LIST_PLACEHOLDER" in translation files
- add "MULTI_SELECTION_LIST_NO_ITEMS" in translation files
- add "MULTI_SELECTION_REQUIRED" in translation files

----------------------------------------------------------------------------------------------------------------------------
5.0.7.0 (2019-05-20)
----------------------------------------------------------------------------------------------------------------------------

- update layout/systemWorkflowDetails/desktop.json
- delete layout/systemWorkflowDetails/mobile.json
- add MainToolbarMobile section inside theme.json
- add News section inside theme.json
- add application button in menu.desktop
- add "ERROR_FILE_MAX_ATTACHMENT_NUMBER" in translation files
- add "ERROR_FILE_ATTACHMENT_NUMBER" in translation files
- add "CPM_DETAIL_HOMEPAGE_TYPE" in translation files
- delete "CPM_DETAIL_LAYOUT" in translation files
- add "CPM_DETAIL_HOMEPAGE" in translation files
